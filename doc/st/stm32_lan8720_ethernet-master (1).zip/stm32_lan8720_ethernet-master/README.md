FreeRTOS 8.2 + LwIP 1.4.1 + LAN8720 + stm32f4-discovery example.

Board addr: 192.168.1.2
Mask: 255.255.255.0
Gw: 192.168.1.1
