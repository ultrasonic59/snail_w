usb2can
=======

USB/Serial to CAN bus converter

![PCB](/../master/usb2can_pcb.png?raw=true "USB2CAN PCB")

